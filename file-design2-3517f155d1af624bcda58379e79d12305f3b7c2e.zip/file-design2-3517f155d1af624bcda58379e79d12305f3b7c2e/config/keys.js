module.exports={
mongoURI:'mongodb+srv://<haneenUser>:<haneen123>@cluster0-1v26k.mongodb.net/test?retryWrites=true&w=majority'
}